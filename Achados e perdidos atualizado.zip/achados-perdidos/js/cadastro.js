/**
 * Cadastro de objetos (UC01 / UC02)
 */

function initCadastroForm(tipo) {
  const formId = tipo === 'perdido' ? 'form-perdido' : 'form-achado';
  const form = document.getElementById(formId);
  if (!form) return;

  const fileInput = document.getElementById('foto');
  const fileUpload = document.getElementById('file-upload');
  const filePreview = document.getElementById('file-preview');
  const previewImg = document.getElementById('preview-img');
  const fotoError = document.getElementById('foto-error');

  // Drag & drop + preview
  if (fileUpload && fileInput) {
    ['dragenter', 'dragover'].forEach(evt => {
      fileUpload.addEventListener(evt, (e) => {
        e.preventDefault();
        fileUpload.classList.add('dragover');
      });
    });
    ['dragleave', 'drop'].forEach(evt => {
      fileUpload.addEventListener(evt, (e) => {
        e.preventDefault();
        fileUpload.classList.remove('dragover');
      });
    });

    fileUpload.addEventListener('drop', (e) => {
      const files = e.dataTransfer.files;
      if (files.length) {
        fileInput.files = files;
        handlePreview(files[0]);
      }
    });

    fileInput.addEventListener('change', () => {
      if (fileInput.files.length) {
        handlePreview(fileInput.files[0]);
      }
    });
  }

  function handlePreview(file) {
    if (fotoError) {
      fotoError.style.display = 'none';
      fotoError.textContent = '';
    }
    readFileAsDataURL(file)
      .then(dataUrl => {
        if (previewImg) previewImg.src = dataUrl;
        if (filePreview) filePreview.classList.add('show');
      })
      .catch(err => {
        if (fotoError) {
          fotoError.textContent = err.message;
          fotoError.style.display = 'block';
        }
        if (filePreview) filePreview.classList.remove('show');
        fileInput.value = '';
      });
  }

  function clearErrors() {
    form.querySelectorAll('.form-group').forEach(g => g.classList.remove('has-error'));
  }

  function showFieldError(groupId) {
    const group = document.getElementById(groupId);
    if (group) group.classList.add('has-error');
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors();

    const descricao = form.descricao?.value.trim();
    const categoria = form.categoria?.value;
    const cor = (form.cor?.value || '').trim() || 'Não informado';
    const local = (form.local?.value || '').trim() || 'Não informado';
    const data = form.data?.value || new Date().toISOString().slice(0, 10);
    let localGuarda = null;

    let hasError = false;

    if (!descricao) {
      showFieldError('group-descricao');
      hasError = true;
    }
    if (!categoria) {
      showFieldError('group-categoria');
      hasError = true;
    }

    if (tipo === 'encontrado') {
      localGuarda = (form.localGuarda?.value || '').trim();
      if (!localGuarda) {
        showFieldError('group-localGuarda');
        hasError = true;
      }
    }

    if (hasError) {
      showToast('Preencha os campos obrigatórios.', 'error');
      return;
    }

    let foto = '';
    if (fileInput?.files?.length) {
      try {
        foto = await readFileAsDataURL(fileInput.files[0]);
      } catch (err) {
        showToast(err.message, 'error');
        return;
      }
    }

    const item = {
      tipo: tipo === 'perdido' ? 'perdido' : 'encontrado',
      descricao,
      categoria,
      cor,
      local,
      localGuarda,
      data,
      foto
    };

    addItem(item);
    showToast(
      tipo === 'perdido'
        ? 'Objeto perdido cadastrado com sucesso!'
        : 'Objeto encontrado cadastrado com sucesso!',
      'success'
    );

    form.reset();
    if (filePreview) filePreview.classList.remove('show');
    if (previewImg) previewImg.src = '';

    setTimeout(() => {
      window.location.href = '../index.html';
    }, 1200);
  });
}
