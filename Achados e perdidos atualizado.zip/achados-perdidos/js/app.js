/**
 * Achados & Perdidos Digital - Core Application
 * Maximus Tech · IFPB Campus Monteiro
 */

const STORAGE_KEY = 'achados_perdidos_data';
const CONTACTS_KEY = 'achados_perdidos_contacts';

const DEFAULT_ITEMS = [
  {
    id: 1,
    tipo: 'perdido',
    descricao: 'Fone de ouvido Bluetooth preto',
    categoria: 'Eletrônicos',
    cor: 'Preto',
    local: 'Biblioteca',
    localGuarda: null,
    data: '2026-09-01',
    foto: '',
    status: 'pendente',
    validado: false,
    devolvido: false
  },
  {
    id: 2,
    tipo: 'encontrado',
    descricao: 'Garrafa térmica azul 500ml',
    categoria: 'Acessórios',
    cor: 'Azul',
    local: 'Pátio',
    localGuarda: 'Coordenação',
    data: '2026-09-02',
    foto: '',
    status: 'validado',
    validado: true,
    devolvido: false
  },
  {
    id: 3,
    tipo: 'perdido',
    descricao: 'Caderno universitário capa preta',
    categoria: 'Material escolar',
    cor: 'Preto',
    local: 'Salas de aula',
    localGuarda: null,
    data: '2026-08-28',
    foto: '',
    status: 'pendente',
    validado: false,
    devolvido: false
  },
  {
    id: 4,
    tipo: 'encontrado',
    descricao: 'Carteira de couro preta',
    categoria: 'Acessórios',
    cor: 'Preto',
    local: 'Coordenação',
    localGuarda: 'Coordenação',
    data: '2026-09-03',
    foto: '',
    status: 'validado',
    validado: true,
    devolvido: false
  },
  {
    id: 5,
    tipo: 'perdido',
    descricao: 'Pen drive 32GB Kingston',
    categoria: 'Eletrônicos',
    cor: 'Preto',
    local: 'Laboratórios',
    localGuarda: null,
    data: '2026-08-30',
    foto: '',
    status: 'pendente',
    validado: false,
    devolvido: false
  },
  {
    id: 6,
    tipo: 'encontrado',
    descricao: 'Óculos de grau armação preta',
    categoria: 'Acessórios',
    cor: 'Preto',
    local: 'Biblioteca',
    localGuarda: 'Biblioteca',
    data: '2026-09-01',
    foto: '',
    status: 'validado',
    validado: true,
    devolvido: false
  },
  {
    id: 7,
    tipo: 'perdido',
    descricao: 'Chaveiro com chave de casa',
    categoria: 'Outros',
    cor: 'Outros',
    local: 'Pátio',
    localGuarda: null,
    data: '2026-09-02',
    foto: '',
    status: 'pendente',
    validado: false,
    devolvido: false
  },
  {
    id: 8,
    tipo: 'encontrado',
    descricao: 'Mochila cinza com livros',
    categoria: 'Material escolar',
    cor: 'Outros',
    local: 'Salas de aula',
    localGuarda: 'Secretaria',
    data: '2026-08-29',
    foto: '',
    status: 'validado',
    validado: true,
    devolvido: false
  }
];

/* ========== Storage ========== */
function getItems() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_ITEMS));
      return [...DEFAULT_ITEMS];
    }
    return JSON.parse(data);
  } catch (e) {
    console.error('Erro ao ler localStorage:', e);
    return [...DEFAULT_ITEMS];
  }
}

function saveItems(items) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    console.error('Erro ao salvar localStorage:', e);
  }
}

function getNextId() {
  const items = getItems();
  if (items.length === 0) return 1;
  return Math.max(...items.map(i => i.id)) + 1;
}

function addItem(item) {
  const items = getItems();
  const newItem = {
    ...item,
    id: getNextId(),
    status: 'pendente',
    validado: false,
    devolvido: false,
    foto: item.foto || ''
  };
  items.unshift(newItem);
  saveItems(items);
  return newItem;
}

function updateItem(id, updates) {
  const items = getItems();
  const index = items.findIndex(i => i.id === id);
  if (index === -1) return null;
  items[index] = { ...items[index], ...updates };
  saveItems(items);
  return items[index];
}

function deleteItem(id) {
  let items = getItems();
  items = items.filter(i => i.id !== id);
  saveItems(items);
  return true;
}

function getItemById(id) {
  return getItems().find(i => i.id === Number(id)) || null;
}

/* Contacts (UC05) */
function getContacts() {
  try {
    const data = localStorage.getItem(CONTACTS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function addContact(contact) {
  const contacts = getContacts();
  contacts.push({
    ...contact,
    id: Date.now(),
    dataSolicitacao: new Date().toISOString()
  });
  localStorage.setItem(CONTACTS_KEY, JSON.stringify(contacts));
}

/* ========== Utils ========== */
function formatDate(dateStr) {
  if (!dateStr) return '—';
  const [y, m, d] = dateStr.split('-');
  return `${d}/${m}/${y}`;
}

function getStatusLabel(item) {
  if (item.devolvido) return 'Devolvido';
  if (item.validado) return 'Validado';
  return 'Pendente';
}

function getStatusClass(item) {
  if (item.devolvido) return 'status-devolvido';
  if (item.validado) return 'status-validado';
  return 'status-pendente';
}

function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function showToast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
    <span class="toast-msg">${escapeHtml(message)}</span>
  `;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add('show'));

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    if (!file) {
      resolve('');
      return;
    }
    if (!file.type.startsWith('image/')) {
      reject(new Error('Formato de imagem inválido. Use JPG, PNG ou WEBP.'));
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      reject(new Error('A imagem deve ter no máximo 2MB.'));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('Erro ao ler a imagem.'));
    reader.readAsDataURL(file);
  });
}

function getPlaceholderImage(tipo, categoria) {
  const colors = {
    'Eletrônicos': '#0b6e4f',
    'Documentos': '#15803d',
    'Material escolar': '#0d8a5f',
    'Acessórios': '#e6a817',
    'Roupas': '#4caf50',
    'Outros': '#558b2f'
  };
  const color = colors[categoria] || '#6b7c76';
  const icon = tipo === 'perdido' ? '🔍' : '📦';
  return `data:image/svg+xml,${encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300">
      <rect fill="${color}" width="400" height="300" rx="12"/>
      <text x="200" y="140" font-size="48" text-anchor="middle" fill="white">${icon}</text>
      <text x="200" y="190" font-size="16" text-anchor="middle" fill="white" opacity="0.9">${categoria || 'Objeto'}</text>
    </svg>
  `)}`;
}

/* Mobile menu & active nav */
function initMobileMenu() {
  const toggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('.nav-menu');
  if (!toggle || !menu) return;

  toggle.addEventListener('click', () => {
    const isOpen = menu.classList.toggle('open');
    toggle.classList.toggle('active', isOpen);
    toggle.setAttribute('aria-expanded', isOpen);
  });

  menu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      menu.classList.remove('open');
      toggle.classList.remove('active');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });
}

function setActiveNav() {
  const path = window.location.pathname;
  document.querySelectorAll('.nav-menu a').forEach(a => {
    a.classList.remove('active');
  });

  if (path.includes('cadastrar-perdido')) {
    document.querySelector('.nav-menu a[href*="cadastrar-perdido"]')?.classList.add('active');
  } else if (path.includes('cadastrar-achado')) {
    document.querySelector('.nav-menu a[href*="cadastrar-achado"]')?.classList.add('active');
  } else if (path.includes('admin')) {
    document.querySelector('.nav-menu a[href*="admin"]')?.classList.add('active');
  } else if (path.includes('detalhes')) {
    // no specific nav
  } else {
    document.querySelector('.nav-menu a[href*="index"]')?.classList.add('active');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initMobileMenu();
  setActiveNav();
});
