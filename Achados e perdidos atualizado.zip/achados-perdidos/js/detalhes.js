/**
 * Página de detalhes do objeto (UC04 + UC05)
 */

(function () {
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  const container = document.getElementById('detalhes-container');
  const notFound = document.getElementById('not-found');

  if (!id || !container) return;

  const item = getItemById(id);

  if (!item) {
    if (notFound) notFound.style.display = 'block';
    if (container) container.style.display = 'none';
    return;
  }

  if (notFound) notFound.style.display = 'none';

  const imgSrc = item.foto || getPlaceholderImage(item.tipo, item.categoria);
  const badgeClass = item.tipo === 'perdido' ? 'badge-perdido' : 'badge-encontrado';
  const badgeText = item.tipo === 'perdido' ? 'Perdido' : 'Encontrado';
  const statusLabel = getStatusLabel(item);
  const statusClass = getStatusClass(item);

  container.innerHTML = `
    <div class="detalhes-grid">
      <div class="detalhes-image">
        <img src="${imgSrc}" alt="Foto de ${escapeHtml(item.descricao)}">
        <span class="card-badge ${badgeClass}">${badgeText}</span>
      </div>
      <div class="detalhes-info">
        <div class="detalhes-header">
          <h1>${escapeHtml(item.descricao)}</h1>
          <span class="status-badge ${statusClass}">${statusLabel}</span>
        </div>

        <dl class="detalhes-meta">
          <div class="meta-row">
            <dt>Categoria</dt>
            <dd>${escapeHtml(item.categoria)}</dd>
          </div>
          <div class="meta-row">
            <dt>Cor</dt>
            <dd>${escapeHtml(item.cor)}</dd>
          </div>
          <div class="meta-row">
            <dt>${item.tipo === 'perdido' ? 'Local aproximado' : 'Local onde foi encontrado'}</dt>
            <dd>${escapeHtml(item.local)}</dd>
          </div>
          ${item.localGuarda ? `
          <div class="meta-row">
            <dt>Local de guarda</dt>
            <dd><strong>${escapeHtml(item.localGuarda)}</strong></dd>
          </div>` : ''}
          <div class="meta-row">
            <dt>Data</dt>
            <dd>${formatDate(item.data)}</dd>
          </div>
        </dl>

        ${!item.devolvido ? `
        <div class="detalhes-actions">
          <button type="button" class="btn btn-primary btn-lg" id="btn-solicitar-contato">
            Solicitar contato intermediado
          </button>
          <a href="../index.html" class="btn btn-outline">Voltar à listagem</a>
        </div>
        ` : `
        <div class="detalhes-actions">
          <p class="devolvido-msg">Este objeto já foi devolvido.</p>
          <a href="../index.html" class="btn btn-outline">Voltar à listagem</a>
        </div>
        `}
      </div>
    </div>
  `;

  // Contact modal logic
  const contactModal = document.getElementById('contact-modal');
  const btnSolicitar = document.getElementById('btn-solicitar-contato');

  btnSolicitar?.addEventListener('click', () => {
    if (item.devolvido) {
      showToast('Este item já foi devolvido. Não é possível solicitar contato.', 'error');
      return;
    }
    contactModal?.classList.add('open');
  });

  function closeContact() {
    contactModal?.classList.remove('open');
  }

  document.getElementById('close-contact-modal')?.addEventListener('click', closeContact);
  document.getElementById('cancel-contact')?.addEventListener('click', closeContact);
  contactModal?.addEventListener('click', (e) => {
    if (e.target === contactModal) closeContact();
  });

  document.getElementById('form-contact')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const form = e.target;
    const nome = form.nome?.value.trim();
    const email = form.email?.value.trim();
    const motivo = form.motivo?.value.trim();

    if (!nome || !email || !motivo) {
      showToast('Preencha todos os campos.', 'error');
      return;
    }

    addContact({
      itemId: item.id,
      itemDescricao: item.descricao,
      nome,
      email,
      motivo
    });

    closeContact();
    form.reset();
    showToast('Solicitação enviada! A administração intermediará o contato.', 'success');
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeContact();
  });
})();
