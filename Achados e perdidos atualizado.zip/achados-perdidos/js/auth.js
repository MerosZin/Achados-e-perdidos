/**
 * Autenticação e controle de acesso por perfil
 * Aluno | Funcionário | Administrador
 * Maximus Tech · IFPB Campus Monteiro
 */

const AUTH_KEY = 'achados_perdidos_auth';

/** Usuários de demonstração (apenas para o protótipo) */
const DEMO_USERS = [
  {
    email: 'aluno@ifpb.edu.br',
    senha: 'aluno123',
    nome: 'João Silva',
    role: 'aluno',
    label: 'Aluno'
  },
  {
    email: 'funcionario@ifpb.edu.br',
    senha: 'func123',
    nome: 'Maria Santos',
    role: 'funcionario',
    label: 'Funcionário'
  },
  {
    email: 'admin@ifpb.edu.br',
    senha: 'admin123',
    nome: 'Admin Sistema',
    role: 'admin',
    label: 'Administrador'
  }
];

function getSession() {
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function setSession(user) {
  const session = {
    email: user.email,
    nome: user.nome,
    role: user.role,
    label: user.label,
    loggedAt: new Date().toISOString()
  };
  localStorage.setItem(AUTH_KEY, JSON.stringify(session));
  return session;
}

function clearSession() {
  localStorage.removeItem(AUTH_KEY);
}

function isLoggedIn() {
  return !!getSession();
}

function isAdmin() {
  const s = getSession();
  return s && s.role === 'admin';
}

function login(email, senha) {
  const emailNorm = (email || '').trim().toLowerCase();
  const senhaNorm = (senha || '').trim();

  const user = DEMO_USERS.find(
    u => u.email.toLowerCase() === emailNorm && u.senha === senhaNorm
  );

  if (!user) {
    return { ok: false, message: 'E-mail ou senha incorretos.' };
  }

  setSession(user);
  return { ok: true, user: getSession() };
}

function logout() {
  clearSession();
}

/**
 * Atualiza a navbar conforme o usuário logado.
 * - Admin: mostra link "Área administrativa"
 * - Aluno/Funcionário: esconde admin
 * - Não logado: mostra "Entrar"
 */
function updateNavAuth() {
  const session = getSession();
  const menus = document.querySelectorAll('.nav-menu');

  menus.forEach(menu => {
    // Remove itens dinâmicos anteriores
    menu.querySelectorAll('[data-auth-item]').forEach(el => el.remove());

    // Esconde link fixo de admin se existir (será recriado se for admin)
    menu.querySelectorAll('a.btn-admin, a[href*="admin.html"]').forEach(a => {
      const li = a.closest('li');
      if (li) li.style.display = 'none';
    });

    if (session) {
      // Nome / perfil
      const liUser = document.createElement('li');
      liUser.setAttribute('data-auth-item', '1');
      liUser.innerHTML = `
        <span class="nav-user" title="${escapeHtml(session.email)}">
          <span class="nav-user-name">${escapeHtml(session.nome)}</span>
          <span class="nav-user-role">${escapeHtml(session.label)}</span>
        </span>
      `;
      menu.appendChild(liUser);

      // Admin só para administrador
      if (session.role === 'admin') {
        const liAdmin = document.createElement('li');
        liAdmin.setAttribute('data-auth-item', '1');
        const isInPages = window.location.pathname.includes('/pages/');
        const adminHref = isInPages ? 'admin.html' : 'pages/admin.html';
        const isAdminPage = window.location.pathname.includes('admin.html');
        liAdmin.innerHTML = `
          <a href="${adminHref}" class="btn-admin${isAdminPage ? ' active' : ''}">Área administrativa</a>
        `;
        menu.appendChild(liAdmin);
      }

      // Sair
      const liOut = document.createElement('li');
      liOut.setAttribute('data-auth-item', '1');
      liOut.innerHTML = `<a href="#" class="nav-logout" id="nav-logout">Sair</a>`;
      menu.appendChild(liOut);

      liOut.querySelector('#nav-logout')?.addEventListener('click', (e) => {
        e.preventDefault();
        logout();
        showToast('Sessão encerrada.', 'info');
        const isInPages = window.location.pathname.includes('/pages/');
        setTimeout(() => {
          window.location.href = isInPages ? '../index.html' : 'index.html';
        }, 500);
      });
    } else {
      // Entrar
      const liLogin = document.createElement('li');
      liLogin.setAttribute('data-auth-item', '1');
      const isInPages = window.location.pathname.includes('/pages/');
      const loginHref = isInPages ? 'login.html' : 'pages/login.html';
      liLogin.innerHTML = `<a href="${loginHref}" class="btn-admin">Entrar</a>`;
      menu.appendChild(liLogin);
    }
  });
}

/**
 * Protege a página admin: só administrador.
 * Aluno e funcionário são redirecionados.
 */
function requireAdmin() {
  const session = getSession();
  if (!session) {
    showToast('Faça login como administrador para acessar esta área.', 'error');
    setTimeout(() => {
      window.location.href = 'login.html?redirect=admin';
    }, 800);
    return false;
  }
  if (session.role !== 'admin') {
    showToast('Acesso negado. Apenas administradores podem acessar esta área.', 'error');
    setTimeout(() => {
      window.location.href = '../index.html';
    }, 1000);
    return false;
  }
  return true;
}

/** Opcional: exige login para cadastro (aluno/funcionário/admin) */
function requireLogin(redirectAfter) {
  if (isLoggedIn()) return true;
  showToast('Faça login para continuar.', 'info');
  const isInPages = window.location.pathname.includes('/pages/');
  const q = redirectAfter ? `?redirect=${encodeURIComponent(redirectAfter)}` : '';
  setTimeout(() => {
    window.location.href = (isInPages ? 'login.html' : 'pages/login.html') + q;
  }, 600);
  return false;
}

// Inicializa navbar em todas as páginas
document.addEventListener('DOMContentLoaded', () => {
  // Garante escapeHtml se app.js ainda não carregou
  if (typeof escapeHtml !== 'function') {
    window.escapeHtml = function (str) {
      if (!str) return '';
      const d = document.createElement('div');
      d.textContent = str;
      return d.innerHTML;
    };
  }
  updateNavAuth();
});
