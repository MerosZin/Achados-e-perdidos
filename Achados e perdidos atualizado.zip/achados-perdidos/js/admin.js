/**
 * Painel Administrativo (UC06)
 */

(function () {
  const sidebar = document.getElementById('admin-sidebar');
  const sidebarToggle = document.getElementById('sidebar-toggle');
  const titleEl = document.getElementById('admin-title');
  const viewDashboard = document.getElementById('view-dashboard');
  const viewTable = document.getElementById('view-table');
  const tbody = document.getElementById('admin-tbody');
  const emptyEl = document.getElementById('admin-empty');
  const statsGrid = document.getElementById('stats-grid');

  let currentView = 'dashboard';
  let deleteId = null;

  sidebarToggle?.addEventListener('click', () => {
    sidebar?.classList.toggle('open');
  });

  document.querySelectorAll('.admin-nav a[data-view]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.admin-nav a').forEach(a => a.classList.remove('active'));
      link.classList.add('active');
      currentView = link.dataset.view;
      sidebar?.classList.remove('open');
      render();
    });
  });

  document.getElementById('btn-logout')?.addEventListener('click', (e) => {
    e.preventDefault();
    if (typeof logout === 'function') logout();
    showToast('Sessão encerrada.', 'info');
    setTimeout(() => { window.location.href = '../index.html'; }, 600);
  });

  function getFilteredItems() {
    const items = getItems();
    if (currentView === 'pendentes') {
      return items.filter(i => !i.validado && !i.devolvido);
    }
    if (currentView === 'validados') {
      return items.filter(i => i.validado || i.devolvido);
    }
    return items;
  }

  function renderStats() {
    if (!statsGrid) return;
    const items = getItems();
    const total = items.length;
    const perdidos = items.filter(i => i.tipo === 'perdido').length;
    const encontrados = items.filter(i => i.tipo === 'encontrado').length;
    const pendentes = items.filter(i => !i.validado && !i.devolvido).length;

    statsGrid.innerHTML = `
      <div class="stat-card">
        <div class="stat-icon total">📦</div>
        <div class="stat-info">
          <h3>${total}</h3>
          <p>Total de objetos</p>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon perdidos">🔴</div>
        <div class="stat-info">
          <h3>${perdidos}</h3>
          <p>Perdidos</p>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon encontrados">🟢</div>
        <div class="stat-info">
          <h3>${encontrados}</h3>
          <p>Encontrados</p>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon pendentes">⏳</div>
        <div class="stat-info">
          <h3>${pendentes}</h3>
          <p>Pendentes</p>
        </div>
      </div>
    `;
  }

  function renderTable() {
    if (!tbody) return;
    const items = getFilteredItems();
    tbody.innerHTML = '';

    if (items.length === 0) {
      if (emptyEl) emptyEl.style.display = 'block';
      return;
    }
    if (emptyEl) emptyEl.style.display = 'none';

    items.forEach(item => {
      const tr = document.createElement('tr');
      const statusLabel = getStatusLabel(item);
      const statusClass = getStatusClass(item);
      const tipoLabel = item.tipo === 'perdido' ? 'Perdido' : 'Encontrado';

      tr.innerHTML = `
        <td class="obj-name">${escapeHtml(item.descricao)}</td>
        <td>${tipoLabel}</td>
        <td>${escapeHtml(item.categoria)}</td>
        <td>${escapeHtml(item.local)}</td>
        <td>${formatDate(item.data)}</td>
        <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
        <td>
          <div class="actions">
            <button class="btn btn-outline btn-sm" data-action="edit" data-id="${item.id}">Editar</button>
            ${!item.validado && !item.devolvido
              ? `<button class="btn btn-success btn-sm" data-action="validar" data-id="${item.id}">Validar</button>`
              : ''}
            <button class="btn btn-danger btn-sm" data-action="delete" data-id="${item.id}">Excluir</button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = Number(btn.dataset.id);
        const action = btn.dataset.action;
        if (action === 'edit') openEdit(id);
        else if (action === 'validar') validarItem(id);
        else if (action === 'delete') openDelete(id);
      });
    });
  }

  function render() {
    const titles = {
      dashboard: 'Dashboard',
      registros: 'Todos os registros',
      pendentes: 'Registros pendentes',
      validados: 'Registros validados'
    };
    if (titleEl) titleEl.textContent = titles[currentView] || 'Administração';

    if (currentView === 'dashboard') {
      if (viewDashboard) viewDashboard.style.display = 'block';
      if (viewTable) viewTable.style.display = 'none';
      renderStats();
    } else {
      if (viewDashboard) viewDashboard.style.display = 'none';
      if (viewTable) viewTable.style.display = 'block';
      renderTable();
    }
  }

  function validarItem(id) {
    updateItem(id, { validado: true, status: 'validado' });
    showToast('Registro validado com sucesso!', 'success');
    render();
  }

  /* Edit modal */
  const editModal = document.getElementById('edit-modal');

  function openEdit(id) {
    const item = getItemById(id);
    if (!item) return;

    document.getElementById('edit-id').value = item.id;
    document.getElementById('edit-descricao').value = item.descricao;
    document.getElementById('edit-categoria').value = item.categoria;
    document.getElementById('edit-cor').value = item.cor;
    document.getElementById('edit-local').value = item.local;
    document.getElementById('edit-localGuarda').value = item.localGuarda || '';
    document.getElementById('edit-data').value = item.data;
    document.getElementById('edit-devolvido').checked = !!item.devolvido;

    const guardaGroup = document.getElementById('edit-guarda-group');
    if (guardaGroup) {
      guardaGroup.style.display = item.tipo === 'encontrado' ? 'block' : 'none';
    }

    editModal?.classList.add('open');
  }

  function closeEdit() {
    editModal?.classList.remove('open');
  }

  document.getElementById('close-edit-modal')?.addEventListener('click', closeEdit);
  document.getElementById('cancel-edit')?.addEventListener('click', closeEdit);
  editModal?.addEventListener('click', (e) => { if (e.target === editModal) closeEdit(); });

  document.getElementById('save-edit')?.addEventListener('click', () => {
    const id = Number(document.getElementById('edit-id').value);
    const descricao = document.getElementById('edit-descricao').value.trim();
    if (!descricao) {
      showToast('A descrição é obrigatória.', 'error');
      return;
    }

    const devolvido = document.getElementById('edit-devolvido').checked;
    const updates = {
      descricao,
      categoria: document.getElementById('edit-categoria').value,
      cor: document.getElementById('edit-cor').value,
      local: document.getElementById('edit-local').value,
      localGuarda: document.getElementById('edit-localGuarda').value || null,
      data: document.getElementById('edit-data').value,
      devolvido,
      status: devolvido ? 'devolvido' : (getItemById(id)?.validado ? 'validado' : 'pendente')
    };

    updateItem(id, updates);
    closeEdit();
    showToast('Registro atualizado com sucesso!', 'success');
    render();
  });

  /* Delete modal */
  const deleteModal = document.getElementById('delete-modal');

  function openDelete(id) {
    const item = getItemById(id);
    if (!item) return;
    deleteId = id;
    const nameEl = document.getElementById('delete-item-name');
    if (nameEl) nameEl.textContent = item.descricao;
    deleteModal?.classList.add('open');
  }

  function closeDelete() {
    deleteModal?.classList.remove('open');
    deleteId = null;
  }

  document.getElementById('close-delete-modal')?.addEventListener('click', closeDelete);
  document.getElementById('cancel-delete')?.addEventListener('click', closeDelete);
  deleteModal?.addEventListener('click', (e) => { if (e.target === deleteModal) closeDelete(); });

  document.getElementById('confirm-delete')?.addEventListener('click', () => {
    if (deleteId == null) return;
    deleteItem(deleteId);
    closeDelete();
    showToast('Registro excluído com sucesso.', 'success');
    render();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeEdit();
      closeDelete();
    }
  });

  render();
})();
