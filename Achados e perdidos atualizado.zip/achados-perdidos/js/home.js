/**
 * Home page - Search, filters & listing (UC03, UC07)
 */

(function () {
  const cardsContainer = document.getElementById('cards-container');
  const emptyState = document.getElementById('empty-state');
  const resultsCount = document.getElementById('results-count');
  const heroForm = document.getElementById('hero-search-form');
  const heroInput = document.getElementById('hero-search-input');
  const filterTipo = document.getElementById('filter-tipo');
  const filterCategoria = document.getElementById('filter-categoria');
  const filterCor = document.getElementById('filter-cor');
  const filterLocal = document.getElementById('filter-local');
  const btnClear = document.getElementById('btn-clear-filters');

  let searchTerm = '';

  function getFilters() {
    return {
      search: searchTerm.trim().toLowerCase(),
      tipo: filterTipo?.value || '',
      categoria: filterCategoria?.value || '',
      cor: filterCor?.value || '',
      local: filterLocal?.value || ''
    };
  }

  function filterItems(items) {
    const f = getFilters();
    return items.filter(item => {
      if (item.devolvido) return false; // hide returned items from public list
      if (f.tipo && item.tipo !== f.tipo) return false;
      if (f.categoria && item.categoria !== f.categoria) return false;
      if (f.cor && item.cor !== f.cor) return false;
      if (f.local && item.local !== f.local) return false;
      if (f.search) {
        const haystack = [
          item.descricao,
          item.categoria,
          item.cor,
          item.local,
          item.localGuarda || ''
        ].join(' ').toLowerCase();
        if (!haystack.includes(f.search)) return false;
      }
      return true;
    });
  }

  function createCard(item) {
    const imgSrc = item.foto || getPlaceholderImage(item.tipo, item.categoria);
    const badgeClass = item.tipo === 'perdido' ? 'badge-perdido' : 'badge-encontrado';
    const badgeText = item.tipo === 'perdido' ? 'Perdido' : 'Encontrado';

    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <div class="card-image">
        <img src="${imgSrc}" alt="Foto de ${escapeHtml(item.descricao)}" loading="lazy">
        <span class="card-badge ${badgeClass}">${badgeText}</span>
      </div>
      <div class="card-body">
        <h3 class="card-title">${escapeHtml(item.descricao)}</h3>
        <div class="card-meta">
          <div class="card-meta-item">📂 <strong>${escapeHtml(item.categoria)}</strong></div>
          <div class="card-meta-item">🎨 Cor: <strong>${escapeHtml(item.cor)}</strong></div>
          <div class="card-meta-item">📍 Local: <strong>${escapeHtml(item.local)}</strong></div>
          <div class="card-meta-item">📅 ${formatDate(item.data)}</div>
        </div>
        <div class="card-footer">
          <a href="pages/detalhes.html?id=${item.id}" class="btn btn-primary btn-block">Ver detalhes</a>
        </div>
      </div>
    `;
    return card;
  }

  function render() {
    if (!cardsContainer) return;

    const items = getItems();
    const filtered = filterItems(items);

    cardsContainer.innerHTML = '';

    if (filtered.length === 0) {
      if (emptyState) emptyState.style.display = 'block';
      if (resultsCount) resultsCount.textContent = '0 objetos encontrados';
    } else {
      if (emptyState) emptyState.style.display = 'none';
      if (resultsCount) {
        resultsCount.textContent = `${filtered.length} objeto${filtered.length !== 1 ? 's' : ''} encontrado${filtered.length !== 1 ? 's' : ''}`;
      }
      filtered.forEach(item => {
        cardsContainer.appendChild(createCard(item));
      });
    }
  }

  if (heroForm) {
    heroForm.addEventListener('submit', (e) => {
      e.preventDefault();
      searchTerm = heroInput.value;
      render();
      document.getElementById('lista')?.scrollIntoView({ behavior: 'smooth' });
    });
  }

  if (heroInput) {
    let debounce;
    heroInput.addEventListener('input', () => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        searchTerm = heroInput.value;
        render();
      }, 300);
    });
  }

  [filterTipo, filterCategoria, filterCor, filterLocal].forEach(el => {
    if (el) el.addEventListener('change', render);
  });

  if (btnClear) {
    btnClear.addEventListener('click', () => {
      searchTerm = '';
      if (heroInput) heroInput.value = '';
      if (filterTipo) filterTipo.value = '';
      if (filterCategoria) filterCategoria.value = '';
      if (filterCor) filterCor.value = '';
      if (filterLocal) filterLocal.value = '';
      render();
    });
  }

  document.addEventListener('DOMContentLoaded', render);
  if (document.readyState !== 'loading') render();
})();
