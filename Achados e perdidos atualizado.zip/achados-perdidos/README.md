# Achados & Perdidos Digital

Sistema web de cadastro, busca e gerenciamento de objetos perdidos e encontrados no **IFPB Campus Monteiro**.

**Equipe:** Maximus Tech  
**Documento de referência:** Casos de Uso e Protótipos v1.4

---

## Funcionalidades implementadas

| UC | Descrição | Status |
|----|-----------|--------|
| UC01 | Cadastrar objeto perdido | ✅ |
| UC02 | Cadastrar objeto encontrado | ✅ |
| UC03 | Buscar e filtrar objetos | ✅ |
| UC04 | Visualizar fotos do objeto | ✅ |
| UC05 | Solicitar contato intermediado | ✅ |
| UC06 | Gerenciar registros (painel admin) | ✅ |
| UC07 | Consultar listagem pública | ✅ |
| — | Login por perfil (Aluno / Funcionário / Admin) | ✅ |

---

## Login e perfis de acesso

| Perfil | E-mail (demo) | Senha | Acesso |
|--------|---------------|-------|--------|
| **Aluno** | aluno@ifpb.edu.br | aluno123 | Cadastro e busca — **sem** área admin |
| **Funcionário** | funcionario@ifpb.edu.br | func123 | Cadastro e busca — **sem** área admin |
| **Administrador** | admin@ifpb.edu.br | admin123 | Acesso total + painel administrativo |

Página de login: `pages/login.html`  
Alunos e funcionários **não** conseguem abrir a área administrativa (redirecionamento + mensagem de acesso negado).

---

## Como executar

### Requisitos
- Navegador moderno (Chrome, Firefox, Edge, Safari)
- Nenhum servidor obrigatório para o frontend (funciona com `file://` ou servidor estático)

### Opção rápida (sem servidor)
1. Abra a pasta do projeto
2. Clique duas vezes em `index.html`

### Com servidor local (recomendado)
```bash
# Python 3
cd achados-perdidos
python -m http.server 8080

# ou Node.js (npx)
npx serve .
```
Acesse: http://localhost:8080

---

## Estrutura de pastas

```
achados-perdidos/
├── index.html              # Página inicial (PT01)
├── css/
│   ├── style.css           # Estilos principais
│   ├── forms.css           # Formulários
│   └── admin.css           # Painel administrativo
├── js/
│   ├── app.js              # Core (storage, utils, toasts)
│   ├── auth.js             # Login e controle de acesso
│   ├── home.js             # Busca e listagem
│   ├── cadastro.js         # Formulários de cadastro
│   ├── detalhes.js         # Detalhes + contato
│   └── admin.js            # Painel admin
├── pages/
│   ├── login.html               # Login (Aluno / Funcionário / Admin)
│   ├── cadastrar-perdido.html   # PT02 / UC01
│   ├── cadastrar-achado.html    # PT03 / UC02
│   ├── detalhes.html            # PT04 / UC04 + UC05
│   └── admin.html               # PT05 / UC06 (somente admin)
├── images/                 # (reservado)
└── README.md
```

---

## Dados

Os registros são armazenados no **localStorage** do navegador.  
Dados de demonstração são carregados automaticamente na primeira visita.

Para limpar os dados:
```js
localStorage.removeItem('achados_perdidos_data');
localStorage.removeItem('achados_perdidos_contacts');
```

---

## Observações técnicas

- Frontend puro: HTML5, CSS3 e JavaScript (sem frameworks)
- Design responsivo (desktop, tablet e mobile)
- Acessibilidade básica (labels, focus, ARIA)
- Validação de formulários e feedback visual (toasts)
- Upload de imagem (base64 no localStorage, máx. 2 MB)
- Contato intermediado: solicitações ficam registradas no localStorage para a administração

---

## Backend Java (estrutura futura)

O projeto atual é **frontend-only**.  
Caso seja necessário evoluir para backend Java, a estrutura sugerida é:

```
backend/
└── src/
    ├── model/          # Entity (Objeto, Contato, Usuario)
    ├── repository/     # DAO / JPA
    ├── service/        # Regras de negócio
    ├── controller/     # Endpoints REST ou servlets
    └── dto/            # Transfer objects
```

---

**Maximus Tech · IFPB Campus Monteiro · 2026**
